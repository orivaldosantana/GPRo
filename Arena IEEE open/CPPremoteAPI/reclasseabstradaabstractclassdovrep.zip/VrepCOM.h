/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#ifndef VREPCOM_H
#define VREPCOM_H
/* 
 * File:   VrepCOM.h
 * Author: root
 *
 * Created on April 18, 2016, 3:29 PM
 */
#include "remoteApi/diferentialDrivenRobot.h"
#include <cstdlib>
#include <iostream>
extern "C"{
    #include "remoteApi/extApi.h"  
};
using namespace std;
/*
 Classe derivada de inteface para comunicacao com o Vrep
 */

class VrepCOM: public diferentialDrivenRobot{
protected:
    string ip;
    int port;
    int clientID;
    simxInt motorHandleR;
    simxInt motorHandleL;
    
public:
    VrepCOM(string IP, int PORT):diferentialDrivenRobot(){
        ip = IP;
        port = PORT;
        motorHandleR = -1;
        motorHandleL = -1;
        clientID = -1;
    }
    
    void ms_delay(int);
    int setup();
    void disconnect();
    bool setMotorSpeedR(float);
    bool setMotorSpeedL(float);
    float getCurrentSpeedR();
    float getCurrentSpeedL();
    int getClientID();
    long getTime();
    

};

#endif /* VREPCOM_H */

