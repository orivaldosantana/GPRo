/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VrepCOM.cpp
 * Author: root
 * 
 * Created on April 18, 2016, 3:29 PM
 */

#include "VrepCOM.h"
#include <stdio.h>

void VrepCOM :: ms_delay(int time){
    extApi_sleepMs(time);
}

float VrepCOM :: getCurrentSpeedR(){
    return 0;
}
float VrepCOM :: getCurrentSpeedL(){
    return 0;
}

long VrepCOM :: getTime(){
    long msec;
    msec = simxGetLastCmdTime(clientID); //dúvidas se o funcionamento dessa funcao vai servir
}

int VrepCOM :: getClientID(){
    return clientID;
}

int VrepCOM::setup(){
    clientID = simxStart((simxChar*) (simxChar*) ip.c_str(), port, true, true, 2000, 5);
    if(clientID != -1){
        cout << simxGetObjectHandle(clientID,(const simxChar*) "RightMotor#",(simxInt*) &motorHandleR,(simxInt) simx_opmode_oneshot_wait) << endl;
        cout << simxGetObjectHandle(clientID,(const simxChar*)"LeftMotor#",(simxInt*) &motorHandleL,(simxInt) simx_opmode_oneshot_wait) << endl;
        cout << motorHandleR << endl;
        simxStartSimulation(clientID, simx_opmode_oneshot_wait);
  
    }
    if(motorHandleR != -1 && motorHandleL !=-1)
        return clientID;
    else 
        return -2;
}

void VrepCOM::disconnect(){
    simxFinish(clientID);
}

bool VrepCOM::setMotorSpeedR(float phi){
   if(motorHandleR != -1)
        simxSetJointTargetVelocity(clientID, motorHandleR, (simxFloat) phi, simx_opmode_streaming);
   else 
       cout << "Handler Direito nao definido" << endl;
}

bool VrepCOM::setMotorSpeedL(float phi){
   if(motorHandleL != -1)
        simxSetJointTargetVelocity(clientID, motorHandleL,(simxFloat) phi, simx_opmode_streaming);
   else 
       cout << "Handler Esquerdo nao definido" << endl;
}
