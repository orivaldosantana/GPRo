/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: root
 *
 * Created on March 22, 2016, 11:24 AM
 */

#include "VrepCOM.h"
#include "robotCOM.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <algorithm>
#include <bits/stringfwd.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <time.h>
#include <tuple>

using namespace std;
int ddRobotHandle;
int leftMotorHandle;
int rightMotorHandle;
int sensorHandle;
int graphOdometryHandle;
int sensorLHandle, sensorFHandle, sensorRHandle, uiHandle;
float position[3];
float orientation[3];
std::vector<int> groups;
vector<float> vecdx,vecdy,vecdtheta;

float theta;
float dx, dy, dtheta;
float dxNormal, dyNormal, dthetaNormal;

float phiR, phiL;
float phiRNormal, phiLNormal;

int estado=0;
ifstream goalArq;

template<typename T>
string ToString(T val){
stringstream stream;
stream << val;
return stream.str();
}

float to_positive_angle(float angle) {

	angle = std::fmod(angle, 2 * M_PI);
	while (angle < 0) {
	  angle = angle + 2 * M_PI;
	}
return angle;
}

float smallestAngleDiff(float target, float source) {
	float a;
	a = to_positive_angle(target) - to_positive_angle(source);

	if (a > M_PI) {
	  a = a - 2 * M_PI;
	} else if (a < -M_PI) {
	  a = a + 2 * M_PI;
	}
	return a;
}


float to180range(float angle) {

	angle = std::fmod(angle, 2 * M_PI);
	if (angle<-M_PI) {
	  angle = angle + 2 * M_PI;
	} else if (angle > M_PI) {
	  angle = angle - 2 * M_PI;
	}
	return angle;
}

inline double to_deg(double radians) {
return radians * (180.0 / M_PI);
}

bool getGoal(float* goal){	
	float dx,dy,dtheta;
	string linha;
	if(estado == 0){
		goalArq.open("goal.txt",ios_base::in);

		if(!goalArq.is_open()){
                cout << "Erro ao ler aquivo goal" << endl;
      }
		else{
			printf("Arquivo aberto\n");
	  		while (getline(goalArq, linha)) {
				dx = atof(strtok(const_cast<char*>(linha.c_str())," "));//dx
            dy = atof(strtok(NULL," "));//dy
            dtheta = atof(strtok(NULL," "));//dTheta
				//printf("Arquivo aberto\n")
				vecdx.push_back(dx);
				vecdy.push_back(dy);
				vecdtheta.push_back(dtheta);		 
	  		}
		}

	}


	if(estado < vecdx.size()){
		goal[0]=vecdx[estado];
		goal[1]=vecdy[estado];
		goal[2]=vecdtheta[estado];
		estado++;
		return true;	
	}

	else return false;
	
}

int main(int argc, char** argv) {
    float position[3], goal[3];
    KBAsync kb;
    int key, passos = 0;
    float rho, alpha, beta;
    float dx, dy;
    float v,w;
    //float k_rho = 0.2,k_alpha= 0.8,k_beta = -0.15;
    float k_rho = 0.3,k_alpha= 0.8,k_beta = -0.15;
    float l = 14.1, rr = 7.0,rl = 7.0;
    
    
    diferentialDrivenRobot* ddR = new VrepCOM("127.0.0.1",19997);
    int clientID = ddR->setup();
    int contador = 0;
    
    if (clientID != -1) {
        printf("Conexao efetuada\n");
        position[0]=0;
        position[1]=0;
        position[2]=0;
        while(getGoal(goal)){
                int cont = 0;
                dy = goal[1]-position[1];
                dx = goal[0]-position[0];
                //printf("%f , %f\n\r",goal[0],goal[1]);
                cont = 0;
                while((abs(dy) > 3 || abs(dx) > 3) && ((key=kb.getKey())!='q') ){
                        //positionArq << position[0] << ' ' << position[1] << endl;
                        rho = sqrt(dx*dx + dy*dy);
                        alpha = smallestAngleDiff(atan2(dy,dx),position[2]);
                        beta = to180range(goal[2] - position[2] - alpha); 
                        //printf("%f : %f\n\r",to180range(smallestAngleDiff(goal[2], position[2])), atan2(dy,dx));
                        v = k_rho*rho;
                        w = k_alpha*alpha + k_beta*beta;
                        //printf("rho:%f, alpha:%f, beta:%f, w:%f\n\r", rho, alpha, beta, w);
                        phiR = (2*v + l*w/2)/(rr/2);
                        phiL = (2*v - l*w/2)/(rl/2);

                        ddR->setMotorSpeedL(phiL);
                        ddR->setMotorSpeedR(phiR);
                        ddR->ms_delay(50);
                        ddR->getRobotPosition(position);
                        printf("dx:%f, dy:%f, dtheta:%f, phiR:%f, phiL:%f\n\r", position[0], position[1], position[2], phiR, phiL);
                        //vRight << ddR->getCurrentSpeedR() << ' ' << phiR << endl;
                        //vLeft << ddR->getCurrentSpeedL() << ' ' << phiL << endl;
                        dy = goal[1]-position[1];
                        dx = goal[0]-position[0];
                        //if(cont%30 ==0)printf("Velocidades: %f, %f\n",phiR,phiL);
                        cont++;		
                }
                cout << dx << " " <<dy<<"\n\r";
                ddR->stopRobot();
                ddR->ms_delay(500);
                cout << "Posição desejada Atingida. Ajustar theta"<< endl;
                cont = 0;
                while(abs(smallestAngleDiff(goal[2],position[2]))>0.05 && ((key=kb.getKey())!='q')){			
                        phiR = 2*smallestAngleDiff(goal[2],position[2]);
                        phiL = -2*smallestAngleDiff(goal[2],position[2]);
                        ddR->setMotorSpeedL(phiL);
                        ddR->setMotorSpeedR(phiR);
                        ddR->ms_delay(50);
                        ddR->getRobotPosition(position);		
                        cout << smallestAngleDiff(goal[2],position[2]) << "\n\r";
                        cont++;
                }
                ddR->stopRobot();
                ddR->ms_delay(5);
        }	 
        cout << (goal[0]-position[0]);
        cout << (goal[1]-position[1]);
        cout << (goal[2]-position[2]) << "\n\r";
        ddR->disconnect();
		
	  
    } else
        printf("Nao foi possivel conectar.\n");
    
    
    
    
    /*if(clientID != -1 && clientID != -2){
        cout << "conectado com sucesso" << clientID << endl;
        while (contador < 1000){
            
            ddR->setMotorSpeedR(10);
            ddR->setMotorSpeedL(-10);
            ddR->ms_delay(10);//delay
            contador ++;
        }
        simxFinish(clientID);
        cout << "CONEXAO FINALIZADA" << endl;
    }
    else if(clientID == -2)
        cout << "ERRO HANDLERS" << endl;
    else{
        simxFinish(clientID);
        cout << "ERRO" << endl;
    }*/ 
        
    return 0;
}

