/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   diferentialDrivenRobot.h
 * Author: root
 *
 * Created on April 18, 2016, 3:14 PM
 */

#ifndef DIFERENTIALDRIVENROBOT_H
#define DIFERENTIALDRIVENROBOT_H


#include <time.h>

/*
Classe abstrata de comunicacao

*/

class diferentialDrivenRobot{
public:
    virtual int setup() = 0;
    virtual void disconnect()=0;
    virtual bool setMotorSpeedR(float)=0; 
    virtual bool setMotorSpeedL(float)=0;
    //seria interessante criar uma funcao para setar as duas velocidades ao mesmo tempo?
    virtual float getCurrentSpeedR()=0;
    virtual float getCurrentSpeedL()=0;
    virtual long getTime()=0; //tempo em segundos
    virtual void ms_delay(int)=0;
    
};


#endif /* DIFERENTIALDRIVENROBOT_H */

